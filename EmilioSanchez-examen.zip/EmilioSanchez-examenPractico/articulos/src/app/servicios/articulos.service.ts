import { Injectable } from '@angular/core';
import { Articulo } from 'src/models/articulo.model';

@Injectable({
  providedIn: 'root'
})
export class ArticulosService {

  private articulos: Array<Articulo> = [
    {nombre: 'zapatilla tela', categoria: 'deportiva', stock: 10, precio: 50},
    {nombre: 'camiseta basica', categoria: 'casual', stock: 25, precio: 15},
    {nombre: 'camiseta estampada', categoria: 'casual', stock: 4, precio: 20},
    {nombre: 'camisa sport', categoria: 'casual', stock: 14, precio: 25},
    {nombre: 'alpargata ante', categoria: 'vestir', stock: 9, precio: 40},
    {nombre: 'sudadera running', categoria: 'deportiva', stock: 3, precio: 30},
    {nombre: 'shorts vaqueros', categoria: 'casual', stock: 8, precio: 24},
    {nombre: 'vaqueros lavados', categoria: 'casual', stock: 10, precio: 31},
    {nombre: 'camisa manga corta', categoria: 'vestir', stock: 120, precio: 19},
    {nombre: 'camisa estampada', categoria: 'casual', stock: 40, precio: 21}
    
  ];

  constructor() { }


  getArticulo(){
    return this.articulos;
  }

  setArticulo(articulo: Articulo) {
    this.articulos.push(articulo);
  }
}
