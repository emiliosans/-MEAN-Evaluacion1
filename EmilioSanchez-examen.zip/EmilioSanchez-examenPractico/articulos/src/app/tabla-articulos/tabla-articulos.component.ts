import { Component, OnInit } from '@angular/core';
import { Articulo } from 'src/models/articulo.model';
import { ArticulosService } from '../servicios/articulos.service';

@Component({
  selector: 'app-tabla-articulos',
  templateUrl: './tabla-articulos.component.html',
  styleUrls: ['./tabla-articulos.component.scss']
})
export class TablaArticulosComponent implements OnInit {

  articulos: Array<Articulo> = [];
  constructor(private articuloService : ArticulosService) { }

  ngOnInit(): void {
    this.articulos = this.articuloService.getArticulo();
  }

}
