import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TablaArticulosComponent } from './tabla-articulos/tabla-articulos.component';

const routes: Routes = [
  {path: '', component: TablaArticulosComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
