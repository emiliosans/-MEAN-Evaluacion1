export interface Articulo {
    nombre: string,
    categoria: string,
    stock: number,
    precio: number
}